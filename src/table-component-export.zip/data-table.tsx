import { flexRender, type Table as TanstackTable } from "@tanstack/react-table";
import * as React from "react";

import { DataTablePagination } from "@/components/data-table/data-table-pagination";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { getColumnPinningStyle } from "@/lib/data-table";
import { cn } from "@/lib/utils";

interface DataTableProps<TData> extends React.ComponentProps<"div"> {
  table: TanstackTable<TData>;
  actionBar?: React.ReactNode;
  /** Pagination variant: "default" or "simple" (Showing X To Y Of Z Entries) */
  paginationVariant?: "default" | "simple";
  /** Show/hide rows per page dropdown */
  showRowsPerPage?: boolean;
  /** Show/hide selected row count */
  showSelectedCount?: boolean;
  /** Show numbered page buttons */
  showPageNumbers?: boolean;
  /** Callback when a row is clicked */
  onRowClick?: (row: TData) => void;
  /** Custom empty state when no data */
  emptyState?: React.ReactNode;
  /** Show loading skeleton */
  loading?: boolean;
  /** Number of skeleton rows to show when loading */
  loadingRowCount?: number;
  /** Custom className for the table element */
  tableClassName?: string;
  /** Custom className for header rows */
  headerClassName?: string;
  /** Custom className for body rows (function receives row data) */
  rowClassName?: string | ((row: TData) => string);
  /** Page size options for pagination dropdown */
  pageSizeOptions?: number[];
  /** Callback when row selection changes */
  onSelectionChange?: (selectedRows: TData[]) => void;
  /** Make table header sticky on scroll */
  stickyHeader?: boolean;
  /** Show "Go to page" input in pagination */
  showGoToPage?: boolean;
}

export function DataTable<TData>({
  table,
  actionBar,
  children,
  className,
  paginationVariant = "simple",
  showRowsPerPage = false,
  showSelectedCount = false,
  showPageNumbers = true,
  onRowClick,
  emptyState,
  loading = false,
  loadingRowCount = 5,
  tableClassName,
  headerClassName,
  rowClassName,
  pageSizeOptions,
  onSelectionChange,
  stickyHeader = false,
  showGoToPage = false,
  ...props
}: DataTableProps<TData>) {
  // Track selection changes
  const selectedRowsRef = React.useRef<string[]>([]);

  React.useEffect(() => {
    if (!onSelectionChange) return;

    const selectedRowIds = Object.keys(table.getState().rowSelection);
    const prevSelectedIds = selectedRowsRef.current;

    // Only call if selection actually changed
    if (
      selectedRowIds.length !== prevSelectedIds.length ||
      !selectedRowIds.every((id) => prevSelectedIds.includes(id))
    ) {
      selectedRowsRef.current = selectedRowIds;
      const selectedRows = table
        .getFilteredSelectedRowModel()
        .rows.map((row) => row.original);
      onSelectionChange(selectedRows);
    }
  }, [table.getState().rowSelection, onSelectionChange, table]);

  // Get row className (supports string or function)
  const getRowClassName = (row: TData) => {
    if (typeof rowClassName === "function") {
      return rowClassName(row);
    }
    return rowClassName ?? "";
  };

  // Render loading skeleton
  const renderLoadingSkeleton = () => {
    const columnCount = table.getAllColumns().length;
    return Array.from({ length: loadingRowCount }).map((_, rowIndex) => (
      <TableRow key={`skeleton-${rowIndex}`}>
        {Array.from({ length: columnCount }).map((_, colIndex) => (
          <TableCell key={`skeleton-${rowIndex}-${colIndex}`}>
            <Skeleton className="h-4 w-full" />
          </TableCell>
        ))}
      </TableRow>
    ));
  };

  return (
    <div
      className={cn("flex w-full flex-col gap-2.5 overflow-auto", className)}
      {...props}
    >
      {children}
      <div className={cn("overflow-hidden rounded-md border", stickyHeader && "max-h-[70vh] overflow-auto")}>
        <Table
          className={tableClassName}
          role="grid"
          aria-rowcount={table.getFilteredRowModel().rows.length}
          aria-colcount={table.getAllColumns().length}
        >
          <TableHeader className={stickyHeader ? "sticky top-0 z-10 bg-background" : undefined}>
            {table.getHeaderGroups().map((headerGroup) => (
              <TableRow key={headerGroup.id} className={headerClassName} role="row">
                {headerGroup.headers.map((header) => (
                  <TableHead
                    key={header.id}
                    colSpan={header.colSpan}
                    style={{
                      ...getColumnPinningStyle({ column: header.column }),
                    }}
                  >
                    {header.isPlaceholder
                      ? null
                      : flexRender(
                          header.column.columnDef.header,
                          header.getContext(),
                        )}
                  </TableHead>
                ))}
              </TableRow>
            ))}
          </TableHeader>
          <TableBody>
            {loading ? (
              renderLoadingSkeleton()
            ) : table.getRowModel().rows?.length ? (
              table.getRowModel().rows.map((row) => (
                <TableRow
                  key={row.id}
                  data-state={row.getIsSelected() && "selected"}
                  className={cn(
                    onRowClick ? "cursor-pointer hover:bg-muted/50" : "",
                    getRowClassName(row.original),
                  )}
                  onClick={(e) => {
                    // Don't trigger row click if clicking on interactive elements
                    const target = e.target as HTMLElement;
                    const isInteractive =
                      target.closest("button") ||
                      target.closest("a") ||
                      target.closest("input") ||
                      target.closest("[role='button']") ||
                      target.closest("[data-no-row-click]");
                    if (!isInteractive) {
                      onRowClick?.(row.original);
                    }
                  }}
                >
                  {row.getVisibleCells().map((cell) => (
                    <TableCell
                      key={cell.id}
                      style={{
                        ...getColumnPinningStyle({ column: cell.column }),
                      }}
                    >
                      {flexRender(
                        cell.column.columnDef.cell,
                        cell.getContext(),
                      )}
                    </TableCell>
                  ))}
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell
                  colSpan={table.getAllColumns().length}
                  className="h-24 text-center"
                >
                  {emptyState ?? "No results."}
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
      <div className="flex flex-col gap-2.5">
        <DataTablePagination
          table={table}
          variant={paginationVariant}
          showRowsPerPage={showRowsPerPage}
          showSelectedCount={showSelectedCount}
          showPageNumbers={showPageNumbers}
          pageSizeOptions={pageSizeOptions}
          showGoToPage={showGoToPage}
        />
        {actionBar &&
          table.getFilteredSelectedRowModel().rows.length > 0 &&
          actionBar}
      </div>
    </div>
  );
}
