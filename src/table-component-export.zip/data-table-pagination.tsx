import type { Table } from "@tanstack/react-table";
import {
  ChevronLeft,
  ChevronRight,
  ChevronsLeft,
  ChevronsRight,
} from "lucide-react";
import * as React from "react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";

interface DataTablePaginationProps<TData> extends React.ComponentProps<"div"> {
  table: Table<TData>;
  pageSizeOptions?: number[];
  /** "default" = original style, "simple" = "Showing X To Y Of Z Entries" */
  variant?: "default" | "simple";
  /** Show/hide "Rows per page" dropdown */
  showRowsPerPage?: boolean;
  /** Show/hide "X of Y row(s) selected" text */
  showSelectedCount?: boolean;
  /** Show numbered page buttons (1, 2, 3...) */
  showPageNumbers?: boolean;
  /** Max number of page buttons to show */
  maxVisiblePages?: number;
  /** Show "Go to page" input */
  showGoToPage?: boolean;
}

export function DataTablePagination<TData>({
  table,
  pageSizeOptions = [10, 20, 30, 40, 50],
  variant = "default",
  showRowsPerPage = true,
  showSelectedCount = true,
  showPageNumbers = false,
  maxVisiblePages = 5,
  showGoToPage = false,
  className,
  ...props
}: DataTablePaginationProps<TData>) {
  const pageIndex = table.getState().pagination.pageIndex;
  const pageSize = table.getState().pagination.pageSize;
  const pageCount = table.getPageCount();
  const totalRows = table.getFilteredRowModel().rows.length;
  const selectedRows = table.getFilteredSelectedRowModel().rows.length;

  // Local state for "Go to page" input
  const [goToPageValue, setGoToPageValue] = React.useState("");

  // Calculate "Showing X To Y Of Z"
  const startRow = pageIndex * pageSize + 1;
  const endRow = Math.min((pageIndex + 1) * pageSize, totalRows);

  // Generate page numbers with ellipsis
  const getPageNumbers = React.useCallback(() => {
    const pages: (number | "ellipsis")[] = [];

    if (pageCount <= maxVisiblePages) {
      // Show all pages
      for (let i = 0; i < pageCount; i++) {
        pages.push(i);
      }
    } else {
      // Always show first page
      pages.push(0);

      // Calculate range around current page
      const start = Math.max(1, pageIndex - 1);
      const end = Math.min(pageCount - 2, pageIndex + 1);

      // Add ellipsis if needed before
      if (start > 1) {
        pages.push("ellipsis");
      }

      // Add pages around current
      for (let i = start; i <= end; i++) {
        pages.push(i);
      }

      // Add ellipsis if needed after
      if (end < pageCount - 2) {
        pages.push("ellipsis");
      }

      // Always show last page
      if (pageCount > 1) {
        pages.push(pageCount - 1);
      }
    }

    return pages;
  }, [pageCount, pageIndex, maxVisiblePages]);

  const isSimple = variant === "simple";

  // Handle "Go to page" submission
  const handleGoToPage = (e: React.FormEvent) => {
    e.preventDefault();
    const pageNum = parseInt(goToPageValue, 10);
    if (!isNaN(pageNum) && pageNum >= 1 && pageNum <= pageCount) {
      table.setPageIndex(pageNum - 1);
      setGoToPageValue("");
    }
  };

  return (
    <div
      className={cn(
        "flex w-full flex-col-reverse items-center justify-between gap-4 overflow-auto p-1 sm:flex-row sm:gap-8",
        className,
      )}
      {...props}
    >
      {/* Left side: Selected count or "Showing X To Y" */}
      <div className="flex-1 whitespace-nowrap text-muted-foreground text-sm">
        {isSimple ? (
          <>
            Showing{" "}
            <span className="font-medium text-foreground">{startRow}</span> To{" "}
            <span className="font-medium text-foreground">{endRow}</span> Of{" "}
            <span className="font-medium text-foreground">{totalRows}</span>{" "}
            Entries
          </>
        ) : (
          showSelectedCount && (
            <>
              {selectedRows} of {totalRows} row(s) selected.
            </>
          )
        )}
      </div>

      {/* Right side: Controls */}
      <div className="flex flex-col-reverse items-center gap-4 sm:flex-row sm:gap-6 lg:gap-8">
        {/* Rows per page dropdown */}
        {showRowsPerPage && !isSimple && (
          <div className="flex items-center space-x-2">
            <p className="whitespace-nowrap font-medium text-sm">
              Rows per page
            </p>
            <Select
              value={`${pageSize}`}
              onValueChange={(value) => {
                table.setPageSize(Number(value));
              }}
            >
              <SelectTrigger className="h-8 w-18 data-size:h-8">
                <SelectValue placeholder={pageSize} />
              </SelectTrigger>
              <SelectContent side="top">
                {pageSizeOptions.map((size) => (
                  <SelectItem key={size} value={`${size}`}>
                    {size}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        )}

        {/* Page indicator (default variant only) */}
        {!isSimple && !showPageNumbers && (
          <div className="flex items-center justify-center font-medium text-sm">
            Page {pageIndex + 1} of {pageCount}
          </div>
        )}

        {/* Navigation buttons */}
        <div className="flex items-center space-x-2">
          {/* First page button (default variant) */}
          {!isSimple && (
            <Button
              aria-label="Go to first page"
              variant="outline"
              size="icon"
              className="hidden size-8 lg:flex"
              onClick={() => table.setPageIndex(0)}
              disabled={!table.getCanPreviousPage()}
            >
              <ChevronsLeft />
            </Button>
          )}

          {/* Previous button */}
          <Button
            aria-label="Go to previous page"
            variant="outline"
            size="icon"
            className="size-8"
            onClick={() => table.previousPage()}
            disabled={!table.getCanPreviousPage()}
          >
            <ChevronLeft />
          </Button>

          {/* Numbered page buttons */}
          {(showPageNumbers || isSimple) && (
            <>
              {getPageNumbers().map((page, idx) =>
                page === "ellipsis" ? (
                  <span
                    key={`ellipsis-${idx}`}
                    className="px-2 text-muted-foreground"
                  >
                    ...
                  </span>
                ) : (
                  <Button
                    key={page}
                    variant={page === pageIndex ? "default" : "outline"}
                    size="icon"
                    className="size-8"
                    onClick={() => table.setPageIndex(page)}
                  >
                    {page + 1}
                  </Button>
                ),
              )}
            </>
          )}

          {/* Next button */}
          <Button
            aria-label="Go to next page"
            variant="outline"
            size="icon"
            className="size-8"
            onClick={() => table.nextPage()}
            disabled={!table.getCanNextPage()}
          >
            <ChevronRight />
          </Button>

          {/* Last page button (default variant) */}
          {!isSimple && (
            <Button
              aria-label="Go to last page"
              variant="outline"
              size="icon"
              className="hidden size-8 lg:flex"
              onClick={() => table.setPageIndex(pageCount - 1)}
              disabled={!table.getCanNextPage()}
            >
              <ChevronsRight />
            </Button>
          )}
        </div>

        {/* Go to page input */}
        {showGoToPage && pageCount > 1 && (
          <form onSubmit={handleGoToPage} className="flex items-center gap-2">
            <span className="whitespace-nowrap text-sm text-muted-foreground">Go to</span>
            <Input
              type="number"
              min={1}
              max={pageCount}
              value={goToPageValue}
              onChange={(e) => setGoToPageValue(e.target.value)}
              placeholder={`1-${pageCount}`}
              className="h-8 w-16 text-center"
              aria-label={`Go to page (1 to ${pageCount})`}
            />
          </form>
        )}
      </div>
    </div>
  );
}
